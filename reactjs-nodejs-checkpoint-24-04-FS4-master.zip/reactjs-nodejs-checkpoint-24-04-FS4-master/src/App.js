import "./App.css";

function App() {
  return (
    <div className="main-content">
    </div>
  );
}

export default App;
